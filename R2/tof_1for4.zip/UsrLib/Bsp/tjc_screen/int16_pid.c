#include "int16_pid.h"
#include <stdint.h>

#define LimitMax(input, max)   \
    {                          \
        if (input > max)       \
        {                      \
            input = max;       \
        }                      \
        else if (input < -max) \
        {                      \
            input = -max;      \
        }                      \
    }

void PID_Init(PidTypeDef *pid, PID_MODE mode, const int32_t PID[3], int32_t max_out, int32_t max_iout)
{
    pid->mode = mode;
    pid->Kp = PID[0];
    pid->Ki = PID[1];
    pid->Kd = PID[2];
    pid->max_out = max_out;
    pid->max_iout = max_iout;
    pid->Dbuf[0] = pid->Dbuf[1] = pid->Dbuf[2] = 0;
    pid->error[0] = pid->error[1] = pid->error[2] = pid->Pout = pid->Iout = pid->Dout = pid->out = 0;
    pid->q_shift = 8;   // [MOD] Ĭ������ 8 λ����Ӧ 256 ��
}

int32_t PID_Calc(PidTypeDef *pid, int32_t ref, int32_t set)
{
    int32_t temp;   // [MOD] ��ʱ������ų˻����ƽ��

    pid->error[2] = pid->error[1];
    pid->error[1] = pid->error[0];
    pid->set = set;
    pid->fdb = ref;
    pid->error[0] = set - ref;

    if (pid->mode == PID_POSITION)
    {
        // P �Kp * error������ q_shift λ
        temp = pid->Kp * pid->error[0];
        pid->Pout = temp >> pid->q_shift;

        // I �Ki * error�����ƺ��ۼ�
        temp = pid->Ki * pid->error[0];
        pid->Iout += temp >> pid->q_shift;

        pid->Dbuf[2] = pid->Dbuf[1];
        pid->Dbuf[1] = pid->Dbuf[0];
        pid->Dbuf[0] = (pid->error[0] - pid->error[1]);

        // D �Kd * Dbuf������
        temp = pid->Kd * pid->Dbuf[0];
        pid->Dout = temp >> pid->q_shift;

        LimitMax(pid->Iout, pid->max_iout);
        pid->out = pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);
    }
    else if (pid->mode == PID_DELTA)
    {
        // ����ʽ P
        temp = pid->Kp * (pid->error[0] - pid->error[1]);
        pid->Pout = temp >> pid->q_shift;

        // ����ʽ I
        temp = pid->Ki * pid->error[0];
        pid->Iout = temp >> pid->q_shift;

        pid->Dbuf[2] = pid->Dbuf[1];
        pid->Dbuf[1] = pid->Dbuf[0];
        pid->Dbuf[0] = (pid->error[0] - 2 * pid->error[1] + pid->error[2]);

        // ����ʽ D
        temp = pid->Kd * pid->Dbuf[0];
        pid->Dout = temp >> pid->q_shift;

        pid->out += pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);
    }
    return pid->out;
}

void PID_clear(PidTypeDef *pid)
{
    pid->error[0] = pid->error[1] = pid->error[2] = 0;
    pid->Dbuf[0] = pid->Dbuf[1] = pid->Dbuf[2] = 0;
    pid->out = pid->Pout = pid->Iout = pid->Dout = 0;
    pid->fdb = pid->set = 0;
}

